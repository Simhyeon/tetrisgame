#!/bin/sh

exec ./tetris
